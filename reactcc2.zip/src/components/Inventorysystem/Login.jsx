import React, { useState } from "react";
import './LoginC.css';
import { FaUser } from "react-icons/fa";
import { FaLock } from "react-icons/fa";
import { useNavigate, Link } from 'react-router-dom';

export const Login = () => {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    username: '',
    password: ''
  });
  const [error, setError] = useState('');

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const validatePassword = (password) => {
    const specialCharPattern = /[!@#$%^&*(),.?":{}|<>]/g;
    return password.length >= 8 && specialCharPattern.test(password);
  };

  const handleLogin = (e) => {
    e.preventDefault();

    // Check if all fields are filled
    if (!form.username || !form.password) {
      setError("Both fields are required.");
      return;
    }

    // Validate password (if needed)
    // if (!validatePassword(form.password)) {
    //   setError("Password must be at least 8 characters long and contain at least one special character.");
    //   return;
    // }

    // Retrieve user details from localStorage
    const userProfile = JSON.parse(localStorage.getItem('profile'));

    // Check if username and password match the stored details
    if (userProfile && userProfile.username === form.username && userProfile.password === form.password) {
      // Clear error message
      setError('');

      // Redirect to homepage
      navigate('/homepage');
    } else {
      setError('Invalid username or password.'); // Handle invalid credentials
    }
  };

  return (
    <div className="wrapper">
      <form onSubmit={handleLogin}>
        <h1>Login</h1>

        {error && <p className="error-message">{error}</p>}

        <div className="input-box">
          <input 
            type="text" 
            name="username" 
            placeholder="Username" 
            value={form.username}
            onChange={handleChange}
            required 
          />
          <FaUser className='icon'/>
        </div>

        <div className="input-box">
          <input 
            type="password" 
            name="password" 
            placeholder="Password" 
            value={form.password}
            onChange={handleChange}
            required 
          />
          <FaLock className='icon'/>
        </div>

        <div className="remember-forgot">
          <label><input type="checkbox" /> Remember me</label>
          <a href="#">Forgot password</a>
        </div>

        <button type="submit">Login</button>

        <div className="new-user">
          <p>New user? <Link to="/signup">Sign up here</Link></p>
        </div>
      </form>
    </div>
  );
};
