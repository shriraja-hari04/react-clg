import React, { useState } from 'react';
import { Link } from 'react-router-dom';  // Import Link for navigation
import './SupplierC.css';

export default function Suppliers() {
  const [suppliers, setSuppliers] = useState([
    { id: 1, name: 'Supplier A', contact: '123-456-7890' },
    { id: 2, name: 'Supplier B', contact: '987-654-3210' },
    { id: 3, name: 'Supplier C', contact: '456-789-1230' },
  ]);

  const [newSupplier, setNewSupplier] = useState({ name: '', contact: '' });
  const [editing, setEditing] = useState(false);
  const [currentSupplier, setCurrentSupplier] = useState(null);

  const handleAddSupplier = () => {
    const newId = suppliers.length + 1;
    setSuppliers([...suppliers, { id: newId, ...newSupplier }]);
    setNewSupplier({ name: '', contact: '' });
  };

  const handleEditSupplier = (supplier) => {
    setEditing(true);
    setCurrentSupplier(supplier);
    setNewSupplier({ name: supplier.name, contact: supplier.contact });
  };

  const handleUpdateSupplier = () => {
    setSuppliers(
      suppliers.map((supplier) =>
        supplier.id === currentSupplier.id ? { ...supplier, ...newSupplier } : supplier
      )
    );
    setEditing(false);
    setNewSupplier({ name: '', contact: '' });
    setCurrentSupplier(null);
  };

  const handleDelete = (id) => {
    setSuppliers(suppliers.filter(supplier => supplier.id !== id));
  };

  return (
    <div className="suppliers-container">
      <h1>Suppliers</h1>
      
      {/* Add/Edit Supplier Form */}
      <div className="supplier-form">
        <input
          type="text"
          placeholder="Supplier Name"
          value={newSupplier.name}
          onChange={(e) => setNewSupplier({ ...newSupplier, name: e.target.value })}
        />
        <input
          type="text"
          placeholder="Contact Info"
          value={newSupplier.contact}
          onChange={(e) => setNewSupplier({ ...newSupplier, contact: e.target.value })}
        />
        <button onClick={editing ? handleUpdateSupplier : handleAddSupplier}>
          {editing ? 'Update Supplier' : 'Add Supplier'}
        </button>
      </div>

      {/* Suppliers Table */}
      <table className="suppliers-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Supplier Name</th>
            <th>Contact Info</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {suppliers.map((supplier) => (
            <tr key={supplier.id}>
              <td>{supplier.id}</td>
              <td>{supplier.name}</td>
              <td>{supplier.contact}</td>
              <td>
                <button onClick={() => handleEditSupplier(supplier)}>Edit</button>
                <button onClick={() => handleDelete(supplier.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Link to go back to Homepage (Placed at the Bottom) */}
      <Link to="/Homepage" className="home-link">Go to Homepage</Link>
    </div>
  );
};
