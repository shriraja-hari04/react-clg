import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './NavbarC.css';

export default function NavBar(){
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('userName'); // Clear user info
    navigate('/'); // Redirect to login page
  };

  return (
    <nav className="navbar">
      <ul className="nav-links">
        {/* <li><Link to="/">Home</Link></li> */}
        {/* <li><Link to="/inventory">Inventory List</Link></li> */}
        <li><Link to="/suppliers">Suppliers</Link></li>
        <li><Link to="/orders">Orders</Link></li>
        <li><Link to="/profile">Profile</Link></li>
        <li><button className="logout-button" onClick={handleLogout}>Logout</button></li>
      </ul>
    </nav>
  );
};
