import React, { useState } from 'react';
import { Link } from 'react-router-dom'; // Link for navigation to Homepage
import './OrdersC.css';

export const Orders = () => {
  const [orders, setOrders] = useState([
    { id: 101, product: 'Laptop', quantity: 5, status: 'Shipped', supplier: 'Supplier A' },
    { id: 102, product: 'Smartphone', quantity: 10, status: 'Processing', supplier: 'Supplier B' },
    { id: 103, product: 'Headphones', quantity: 15, status: 'Delivered', supplier: 'Supplier A' },
  ]);

  const [newOrder, setNewOrder] = useState({ product: '', quantity: '', status: '', supplier: '' });
  const [editing, setEditing] = useState(false);
  const [currentOrder, setCurrentOrder] = useState(null);
  const [supplierFilter, setSupplierFilter] = useState('');

  const filteredOrders = supplierFilter
    ? orders.filter(order => order.supplier === supplierFilter)
    : orders;

  const handleAddOrder = () => {
    const newId = orders.length + 101; // Generating new ID for the order
    setOrders([...orders, { id: newId, ...newOrder }]);
    setNewOrder({ product: '', quantity: '', status: '', supplier: '' });
  };

  const handleEditOrder = (order) => {
    setEditing(true);
    setCurrentOrder(order);
    setNewOrder({
      product: order.product,
      quantity: order.quantity,
      status: order.status,
      supplier: order.supplier,
    });
  };

  const handleUpdateOrder = () => {
    setOrders(
      orders.map((order) =>
        order.id === currentOrder.id ? { ...order, ...newOrder } : order
      )
    );
    setEditing(false);
    setNewOrder({ product: '', quantity: '', status: '', supplier: '' });
    setCurrentOrder(null);
  };

  const handleDeleteOrder = (id) => {
    setOrders(orders.filter(order => order.id !== id));
  };

  return (
    <div className="orders-container">
      <h1>Orders</h1>

      {/* Supplier Filter */}
      <div className="filter-container">
        <label>Filter by Supplier:</label>
        <input
          type="text"
          placeholder="Enter supplier name"
          value={supplierFilter}
          onChange={(e) => setSupplierFilter(e.target.value)}
        />
      </div>

      {/* Add/Edit Order Form */}
      <div className="order-form">
        <input
          type="text"
          placeholder="Product"
          value={newOrder.product}
          onChange={(e) => setNewOrder({ ...newOrder, product: e.target.value })}
        />
        <input
          type="number"
          placeholder="Quantity"
          value={newOrder.quantity}
          onChange={(e) => setNewOrder({ ...newOrder, quantity: e.target.value })}
        />
        <input
          type="text"
          placeholder="Status"
          value={newOrder.status}
          onChange={(e) => setNewOrder({ ...newOrder, status: e.target.value })}
        />
        <input
          type="text"
          placeholder="Supplier"
          value={newOrder.supplier}
          onChange={(e) => setNewOrder({ ...newOrder, supplier: e.target.value })}
        />
        <button onClick={editing ? handleUpdateOrder : handleAddOrder}>
          {editing ? 'Update Order' : 'Add Order'}
        </button>
      </div>

      {/* Orders Table */}
      <table className="orders-table">
        <thead>
          <tr>
            <th>Order ID</th>
            <th>Product</th>
            <th>Quantity</th>
            <th>Status</th>
            <th>Supplier</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredOrders.map((order) => (
            <tr key={order.id}>
              <td>{order.id}</td>
              <td>{order.product}</td>
              <td>{order.quantity}</td>
              <td>{order.status}</td>
              <td>{order.supplier}</td>
              <td>
                <button onClick={() => handleEditOrder(order)}>Edit</button>
                <button onClick={() => handleDeleteOrder(order.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Link to go back to Homepage */}
      <Link to="/Homepage" className="home-link">Go to Homepage</Link>
    </div>
  );
};
