import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom'; // Link for navigation to Homepage
import './ProfileC.css';

export const Profile = () => {
  // Get user details from localStorage (set in login page)
  const storedProfile = JSON.parse(localStorage.getItem('profile')) || {
    username: 'John Doe',
    email: 'john.doe@example.com',
    business: 'John’s Supplies',
    joined: 'January 2023',
  };

  const [profile, setProfile] = useState(storedProfile);

  const handleChange = (e) => {
    setProfile({ ...profile, [e.target.name]: e.target.value });
  };

  const handleUpdate = () => {
    // Update localStorage with new profile details
    localStorage.setItem('profile', JSON.stringify(profile));
    alert('Profile updated successfully!');
  };

  useEffect(() => {
    // If login data is available in localStorage, set profile with login data
    const loggedInUser = localStorage.getItem('userName');
    if (loggedInUser) {
      setProfile((prevProfile) => ({
        ...prevProfile,
        username: loggedInUser,
      }));
    }
  }, []);

  return (
    <div className="profile-container">
      <h1>Profile</h1>
      <div className="profile-info">
        <p><strong>Name:</strong> <input type="text" name="username" value={profile.username} onChange={handleChange} /></p>
        <p><strong>Email:</strong> <input type="email" name="email" value={profile.email} onChange={handleChange} /></p>
        <p><strong>Business:</strong> <input type="text" name="business" value={profile.business} onChange={handleChange} /></p>
        <p><strong>Joined:</strong> {profile.joined}</p>
        <button onClick={handleUpdate}>Update Profile</button>
      </div>

      {/* Link to go back to Homepage */}
      <Link to="/Homepage" className="home-link">Go to Homepage</Link>
    </div>
  );
};
