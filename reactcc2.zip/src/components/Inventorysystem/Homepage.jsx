import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './HomepageC.css';
import './Login.jsx';
import { useNavigate } from 'react-router-dom';
import NavBar  from './NavBar.jsx';
function Homepage() {
  const navigate = useNavigate();
  const [inventory, setInventory] = useState([]);
  const [form, setForm] = useState({ id: null, name: '', rate: '' });
  const [isEditing, setIsEditing] = useState(false);

  // Fetch inventory from jsonplaceholder when component mounts
  useEffect(() => {
    axios.get('https://jsonplaceholder.typicode.com/posts')
      .then((response) => {
        // Simulate using the fetched data for inventory
        const fetchedInventory = response.data.slice(0, 5).map(post => ({
          id: post.id,
          name: post.title,
          rate: Math.floor(Math.random() * 1000), // Generate a random rate
        }));
        setInventory(fetchedInventory);
      })
      .catch((error) => {
        console.error('Error fetching inventory:', error);
      });
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const addItem = (e) => {
    e.preventDefault();
    if (!form.name || !form.rate || form.rate <= 0) return;

    const newItem = {
      id: Date.now(),
      name: form.name,
      rate: parseFloat(form.rate),
    };

    axios.post('https://jsonplaceholder.typicode.com/posts', newItem)
      .then((response) => {
        console.log('Item added:', response.data);
        setInventory([...inventory, newItem]);
        setForm({ id: null, name: '', rate: '' });
      })
      .catch((error) => {
        console.error('Error adding item:', error);
      });
  };

  const deleteItem = (id) => {
    axios.delete(`https://jsonplaceholder.typicode.com/posts/${id}`)
      .then(() => {
        setInventory(inventory.filter((item) => item.id !== id));
      })
      .catch((error) => {
        console.error('Error deleting item:', error);
      });
  };

  const editItem = (item) => {
    setIsEditing(true);
    setForm({ id: item.id, name: item.name, rate: item.rate });
  };

  const updateItem = (e) => {
    e.preventDefault();
    axios.put(`https://jsonplaceholder.typicode.com/posts/${form.id}`, form)
      .then(() => {
        setInventory(
          inventory.map((item) =>
            item.id === form.id ? { ...item, name: form.name, rate: parseFloat(form.rate) } : item
          )
        );
        setIsEditing(false);
        setForm({ id: null, name: '', rate: '' });
      })
      .catch((error) => {
        console.error('Error updating item:', error);
      });
  };

  const name = localStorage.getItem('userName');

  return (
    
    <div className="container">
       <NavBar />
      <header>
        <h1>Inventory Management System</h1>
        <h2>{name}</h2>
      </header>

      <div className="main-content">
        <div className="form-section">
          {isEditing ? (
            <form onSubmit={updateItem}>
              <h2>Update Item</h2>
              <input
                type="text"
                name="name"
                placeholder="Item Name"
                value={form.name}
                onChange={handleChange}
                required
              />
              <input
                type="number"
                name="rate"
                placeholder="Rate"
                value={form.rate}
                onChange={handleChange}
                required
              />
              <button type="submit" className="btn update">
                Update
              </button>
              <button
                type="button"
                className="btn cancel"
                onClick={() => {
                  setIsEditing(false);
                  setForm({ id: null, name: '', rate: '' });
                }}
              >
                Cancel
              </button>
            </form>
          ) : (
            <form onSubmit={addItem}>
              <h2>Add New Item</h2>
              <input
                type="text"
                name="name"
                placeholder="Item Name"
                value={form.name}
                onChange={handleChange}
                required
              />
              <input
                type="number"
                name="rate"
                placeholder="Rate"
                value={form.rate}
                onChange={handleChange}
                required
              />
              <button type="submit" className="btn add">
                Add Item
              </button>
              {/* <button class="b" onClick={() => navigate('/')}>Logout</button> */}
            </form>
          )}
        </div>

        <div className="table-section">
          <h2>Current Inventory</h2>
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Item Name</th>
                <th>Rate ($)</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {inventory.length > 0 ? (
                inventory.map((item) => (
                  <tr key={item.id}>
                    <td>{item.id}</td>
                    <td>{item.name}</td>
                    <td>{item.rate.toFixed(2)}</td>
                    <td>
                      <button className="btn edit" onClick={() => editItem(item)}>
                        Edit
                      </button>
                      <button className="btn delete" onClick={() => deleteItem(item.id)}>
                        Delete
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="4">No items available.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <footer>
        <p>&copy; 2024 Inventory Management System. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default Homepage;
