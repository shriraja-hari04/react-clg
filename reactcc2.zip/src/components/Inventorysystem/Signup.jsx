import React, { useState } from "react";
import './SignupC.css';
import { FaUser } from "react-icons/fa";
import { FaLock } from "react-icons/fa";
import { MdBusinessCenter } from "react-icons/md";
import { MdEmail } from "react-icons/md";
import { useNavigate, Link } from 'react-router-dom';

export const Signup = () => {
  const [form, setForm] = useState({
    username: '',
    password: '',
    businessName: '',
    email: ''
  });
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const validatePassword = (password) => {
    const specialCharPattern = /[!@#$%^&*(),.?":{}|<>]/g;
    return password.length >= 8 && specialCharPattern.test(password);
  };

  const handleSignup = (e) => {
    e.preventDefault(); 

    // Check if all fields are filled
    if (!form.username || !form.password || !form.businessName || !form.email) {
      setError("All fields must be filled.");
      return;
    }

    // Check password validation
    if (!validatePassword(form.password)) {
      setError("Password must be at least 8 characters long and contain at least one special character.");
      return;
    }

    // Store user details in localStorage
    const userProfile = {
      username: form.username,
      password: form.password, // Include password
      business: form.businessName,
      email: form.email,
      joined: new Date().toLocaleDateString(), // Current date as joined date
    };
    localStorage.setItem('profile', JSON.stringify(userProfile));

    setError(''); // Clear any existing errors
    navigate('/'); // Redirect to login page or homepage after signup
  };

  return (
    <div className="wrapper">
      <form onSubmit={handleSignup}>
        <h1>Sign Up</h1>

        {error && <p className="error-message">{error}</p>}

        <div className="input-box">
          <input 
            type="text" 
            name="username" 
            placeholder="Username" 
            value={form.username}
            onChange={handleChange}
            required 
          />
          <FaUser className='icon'/>
        </div>

        <div className="input-box">
          <input 
            type="password" 
            name="password" 
            placeholder="Password" 
            value={form.password}
            onChange={handleChange}
            required 
          />
          <FaLock className='icon'/>
        </div>

        <div className="input-box">
          <input 
            type="text" 
            name="businessName" 
            placeholder="Business Name" 
            value={form.businessName}
            onChange={handleChange}
            required 
          />
          <MdBusinessCenter className='icon' />
        </div>

        <div className="input-box">
          <input 
            type="email" 
            name="email" 
            placeholder="Email id" 
            value={form.email}
            onChange={handleChange}
            required 
          />
          <MdEmail className='icon'/>
        </div>

        <div className="remember-forgot">
          <label> <input type="checkbox" /> Remember me</label>
          <a href="#">Forgot password</a>
        </div>

        <button type="submit">Create Account</button>
      </form>
    </div>
  );
};
