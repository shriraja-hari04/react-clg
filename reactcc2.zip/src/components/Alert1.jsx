import React from "react";
import App from "../App";
export default Alert1=(props)=>
{
    return(
        <div>
           alert({props.name})
        </div>   
    )
}
