import React from "react";
import { Button } from "@mui/material";
class TwoWay 
{
    const TwoWay=()=>
    {
       <div>

       </div>
    }
}