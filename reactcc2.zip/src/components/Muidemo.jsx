import React from "react";
import  Button  from "@mui/material/Button";
import { AccessAlarm, ThreeDRotation } from '@mui/icons-material';
function Muidemo()
{
    return(
        <div>
            <Button variant="text" color="error">Text</Button>
            <Button variant="contained" color="error">Contained</Button>
            <HomeIcon fontSize="large" />
            <HomeIcon sx={{ fontSize: 40 }} />
        </div>
    )
}
export default Muidemo;