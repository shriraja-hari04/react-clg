import React from 'react';
function Welcome()
{
    return(
        <div>
        <h1>hello world</h1>
        <h2>welcome to react</h2>
        </div>
    );
};
export default Welcome;