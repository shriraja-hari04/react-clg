import { Component } from "react";

class Sample extends Component
{
    constructor()
    {
        super();
            this.state=
            {
               name:"hari"
            };
    }
     display()
    { 
        console.log(this.state.name)
    
    }
}
export default Sample;

