import React, { useState } from 'react';
function Day3DC() {
  const [tasks, setTasks] = useState([
    { id: 1, name: 'Task 1' },
    { id: 2, name: 'Task 2' },
    { id: 3, name: 'Task 3' },
  ]);

  const deleteTask = (id) => {
    setTasks(tasks.filter(task => task.id !== id));
  };

  return (
    <div style={{ backgroundColor:"lightpink", width:"200px",height:"200px",margin:"auto"}}>
      <h2 style={{textAlign:"center"}}>Task List</h2>
      {tasks.map(task => (
        <div key={task.id} style={{  display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
          <span style={{ paddingLeft:"40px",  marginRight: '10px' }}>{task.name}</span>
          <button onClick={() => deleteTask(task.id)} style={{ backgroundColor: 'red', color: 'white', border: 'none', padding: '5px 10px' }}>Delete</button>
        </div>
      ))}
    </div>
  );
}

export default Day3DC;
