import React,{useState} from "react";
function Goku()
{
    const [ischange,setischange]=useState(true);
    function change()
    {
        setischange(!ischange);
    }
    return(
        <div>
              <button onClick={change}>{ischange ? "kaioken" : "SuperSaiyan"}</button>
        </div>
    )
}
export default Goku;