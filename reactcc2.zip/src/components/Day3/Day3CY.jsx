import React,{useState} from "react";
function Day3CY()
{ 
       const [iswe,setiswe]=useState(" ");
       function change()
       {
        setiswe(iswe);
       }
    return(
        <div class="f" style={{backgroundColor:"pink",width:"500px",height:"500px",margin:"auto"}}>
              <input type="text" value={iswe} id="t" placeholder="loc" onChange={(e) => setiswe(e.target.value)} // Update state as the input changes
              />
              <button onClick={change}>Update Location</button>
              <h1>Current Weather in {iswe}</h1>
              <p>Temperature :20 c</p>
              <p>Condition Sunny</p>
        </div>
    )
}
export default Day3CY;


