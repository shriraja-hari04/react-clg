import React from "react";
import './Day2CYC.css';
function Day2CY()
{
    return(
        <div class="f">
            <h1>Smile component</h1>
            <h2>It is a functional component</h2>
            <div class="s">

            </div>
        </div>
    )
}
export default Day2CY;