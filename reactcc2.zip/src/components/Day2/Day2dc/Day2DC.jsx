import React from "react";
import './Day2DCC.css';
function Day2DC()
{
    return(
        <div>
            <div class="f">
               <h1>Car and Location Info</h1>
               <div class="s">
            <h2>Tesla Model S</h2>
            <div class="ss">

            </div>
            </div>
            <div class="t">
            <h3>Tesla</h3>
            <h4>Palo Alto</h4>
         </div>
         </div>
         
       
           

        
        </div>
    )
}
export default Day2DC;