import React from "react";
function greeting(props)
{
    return(
        <div>
        <h1>Hi {props.id}</h1>
        </div>
    )
};
export default greeting;