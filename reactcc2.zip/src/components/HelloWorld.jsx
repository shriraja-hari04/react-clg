import React from "react";
import { Component } from "react";
class HelloWorld extends Component
{
    state={
      add:1
    }
    addme =()=>
    {
        this.setState(prevState=>({
            add:prevState.add+1
        }))
    }

    //  addme=()=>
    // {
    //     this.setState({add:this.state.add+1})
        
    // }
    render()
    {
        return (
            <div>
                <h1>HelloWorld</h1>
                <h1>{this.state.add}</h1>
                <button onClick={this.addme}>click me</button>
            </div>
        ) 
    }
   


};
export default HelloWorld;