import React from 'react';
// import Welcome from './components/Welcome';
// import HelloWorld from './components/HelloWorld';
// import Greeting from './components/Greeting';
//  import Project3 from './components/Project3';
// import Muidemo from './components/Muidemo';
import  {Login} from './components/Inventorysystem/Login';
import {Signup} from './components/Inventorysystem/Signup';
import Homepage from './components/Inventorysystem/Homepage';
 import { BrowserRouter, Route, Routes } from 'react-router-dom';
 import Supplier from './components/Inventorysystem/Supplier';
 import { Orders } from './components/Inventorysystem/Orders.';
 import {Profile} from './components/Inventorysystem/Profile';
// import BasicForm from './components/Project4';
// import Day2DC from './components/Day2DC';
// import Day2CY from './components/Day2CY';
// import Togglemessage from './components/Day3/Day3CW';
// import Goku from './components/Day3/Day3HW';
// import Day3CY from './components/Day3/Day3CY';
// import Day3DC from './components/Day3/Day3DC';
// import Homepage1 from './components/Homepage1/Homepage1';
// import InventoryForm from './components/Homepage1/Inventoryform';
// import InventoryList from './components/Homepage1/Inventorylist';
// import Homepage2 from './components/Homepage1/Homepage1';
// import AddEditItem from './components/Homepage1/Additem';
// import Dashboard from './components/Homepage1/Dashboard';
// import InventoryList from './components/Homepage1/Inventory';
// import Layout from './components/Homepage1/Layout';
function App() {
    return(
        <div>
        <BrowserRouter>
            <Routes>
                <Route path='/signup' element={<Signup/>}/>
                <Route path='/' element={<Login/>}/>
                <Route path='/Homepage' element={<Homepage/>}/>
                <Route path='/suppliers' element={<Supplier/>}/>
                <Route path='/orders' element={<Orders/>}/>
                <Route path='/Profile' element={<Profile/>}/>
            </Routes>
        </BrowserRouter>
        {/* <Welcome/> */}
        {/* <HelloWorld/> */}
        {/* <Greeting id={a}/>  */}
       {/* <Project3/> */}
        {/* <Muidemo/> */}
        {/* <BasicForm/> */}
        {/* <Day2DC/> */}
        {/* <Day2CY/> */}
        {/* <Togglemessage/> */}
        {/* <Goku/> */}
        {/* <Day3CY/> */}
        {/* <Day3DC/> */}
        {/* <Homepage1/> */}
        {/* <Homepage2/>
        <InventoryForm/>
        <InventoryList/> */}
        {/* <BrowserRouter>
            <Routes>
                <Route path='/' element={<Dashboard/>}/>
                <Route path='/inventory' element={<InventoryList/>}/>
                <Route path='/add-item' element={<AddEditItem/>}/>
            </Routes>
        </BrowserRouter>  */}
        </div>
    )
};
export default App;
